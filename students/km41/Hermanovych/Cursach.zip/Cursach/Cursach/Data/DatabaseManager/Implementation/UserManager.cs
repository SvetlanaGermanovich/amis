﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cursach.Data.DatabaseManager.Interface;
using Cursach.Data.Model;
using Oracle.ManagedDataAccess.Client;


namespace Cursach.Data.DatabaseManager.Implementation
{
    public class UserManager : IUserManager
    {
        private readonly string _connectionString;

        public UserManager(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<IEnumerable<AppUser>> GetAllAsync()
        {
            try
            {
                var result = new List<AppUser>();
                using (var connection = new OracleConnection())
                {
                    connection.ConnectionString = _connectionString;
                    await connection.OpenAsync();

                    var command = connection.CreateCommand();
                    var sql = "Select * from AppUser u\nleft join UserInfo ui on ui.id= u.UserInfoId";
                    command.CommandText = sql;
                    var reader = await command.ExecuteReaderAsync();

                    while (reader.ReadAsync().Result)
                    {
                       var user = new AppUser
                       {
                           Id = Convert.ToInt32(reader["Id"]),
                           Email = reader["Email"].ToString(),
                           UserRoleId = Convert.ToInt32(reader["RoleId"]),
                           UserInfoId = Convert.ToInt32(reader["UserInfoId"])
                       };  
                        var userInfo = new UserInfo
                        {
                            Country = reader["Country"].ToString(),
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            DateOfBirth =Convert.ToDateTime(reader["DateOfbirth"])
                        };
                        user.UserInfo = userInfo;
                        result.Add(user);
                    }

                    return result;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<AppUser> GetAsync(string email,string password)
        {
            try
            {
                using (var connection = new OracleConnection())
                {
                    connection.ConnectionString = _connectionString;
                    await connection.OpenAsync();

                    var command = connection.CreateCommand();
                    var sql = $"Select * from AppUser u where u.email='{email}'\nand u.password='{password}'";
                    command.CommandText = sql;
                    var reader = await command.ExecuteReaderAsync();

                    while (reader.ReadAsync().Result)
                    {
                        if (reader.HasRows)
                        {
                            var user = new AppUser
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Email = reader["Email"].ToString(),
                                UserRoleId = Convert.ToInt32(reader["RoleId"]),
                                UserInfoId = Convert.ToInt32(reader["UserInfoId"])
                            };
                            return user;
                        }
                    }
                    return null;
                }

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<AppUser> AddUserAsync(UserInfo userInfo, AppUser user)
        {
            using (var connection = new OracleConnection())
            {
                connection.ConnectionString = _connectionString;
                await connection.OpenAsync();
                   
                var userInfoId = await GetUserInfoId(connection);
                int userId = await GetUserId(connection);

                var dateOfBirth = userInfo.DateOfBirth.ToString("yyyy/MM/dd");
                var sql =
                    "begin\nInsert into userInfo(id,firstname,lastname,gender,dateOfBirth,country)\n" +
                    $"values({userInfoId}," +
                    $"'{userInfo.FirstName}'," +
                    $"'{userInfo.LastName}'," +
                    $"{(int) (userInfo.Gender)}," +
                    $"to_date('{dateOfBirth}','yyyy/mm/dd')," +
                    $"'{userInfo.Country}');\n" +
                    "insert into appUser(id,email,password,userInfoId,roleId)\n" +
                    $"values({userId}," +
                    $"'{user.Email}'," +
                    $"'{user.Password}'," +
                    $"{userInfoId}," +
                    $"{user.UserRoleId});\n" +
                    $"end;";                                
                var command = connection.CreateCommand();
                command.CommandText = sql;

                var transaction = connection.BeginTransaction();
                try
                {
                    command.Transaction = transaction;
                    command.ExecuteNonQuery();
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return null;
                }
                    
                return new AppUser
                {
                    Id = userId,
                    Email = user.Email,
                    UserInfo = new UserInfo
                    {
                        FirstName = userInfo.FirstName,
                        LastName = userInfo.LastName,
                        DateOfBirth = userInfo.DateOfBirth
                    }
                };
            }
            
        }

        public async Task<bool> DeleteUserAsync(int id)
        {
            using (var connection = new OracleConnection())
            {
                connection.ConnectionString = _connectionString;
                await connection.OpenAsync();

                var command = connection.CreateCommand();
                var sql = $"Delete from AppUser u where u.id={id}";
                command.CommandText = sql;
                command.ExecuteNonQuery();

                return true;
            }
        }

        private async Task<int> GetUserId(OracleConnection connection)
        {
            var sql = "select user_seq.nextval from dual";
            var command = connection.CreateCommand();
            command.CommandText = sql;

            var reader = await command.ExecuteReaderAsync();
            var id = 0;
            while (reader.ReadAsync().Result)
            {
                if (reader.HasRows)
                {
                    id = reader.GetInt32(0);
                }
            }
            return id;
        }

        private async Task<int> GetUserInfoId(OracleConnection connection)
        {
            var sql = "select userinfo_seq.nextval from dual";
            var command = connection.CreateCommand();
            command.CommandText = sql;

            var reader = await command.ExecuteReaderAsync();
            var id = 0;
            while (reader.ReadAsync().Result)
            {
                if (reader.HasRows)
                {
                    id = reader.GetInt32(0);
                }
            }
            return id;
        }
    }
}
