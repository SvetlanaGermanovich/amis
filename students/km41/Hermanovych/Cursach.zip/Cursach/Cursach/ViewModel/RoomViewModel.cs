﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cursach.Data.Model;

namespace Cursach.ViewModel
{
    public class RoomViewModel
    {
        public int Id { get; set; }
        public int Floor { get; set; }
        public int NumberOfRoom { get; set; }
        public int HotelId { get; set; }
        public int RoomTypeId { get; set; } = 1;

        public HotelInfo HotelInfo { get; set; }
        public DateTime BookDate { get; set; }
    }
}
