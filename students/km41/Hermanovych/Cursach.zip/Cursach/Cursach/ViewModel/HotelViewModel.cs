﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Services.Description;

namespace Cursach.ViewModel
{
    public class HotelViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Title is required")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Description is required")]
        public string Desctiption { get; set; }
        [Required(ErrorMessage = "Count of stars is required")]
        public int CountOfStars { get; set; } = 3;
        [Required(ErrorMessage = "Street is required")]
        public string Street { get; set; }
        [Required(ErrorMessage = "City is required")]
        public string City { get; set; }
        [Required(ErrorMessage = "Country is required")]
        public string Country { get; set; } = "Ukraine";

        [Required(ErrorMessage = "House number is required")]
        public int HouseNumber { get; set; } = 1;

        public int HotelInfoId { get; set; }
        public int HotelAddressId { get; set; }
    }
}
