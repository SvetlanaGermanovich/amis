﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cursach.Data.Model;

namespace Cursach.Data.DatabaseManager.Interface
{
    public interface IHotelManager
    {
        Task<IEnumerable<Hotel>> GetAllAsync();
        Task<Hotel> GetAsync(int id);
        Task<Hotel> AddAsync(HotelAddress address, HotelInfo info);
        Task<Room> AddRoomAsync(Room room);
        Task<IEnumerable<Room>> GetAllRoomAsync(int hotelId);
        Task<Room> GetRoomAsync(int roomId);
        Task<bool> DeleteAsync(int id);
        Task<bool> AddUserToRoomAsync(int userId, int modelId, DateTime modelBookDate);
        Task<bool> IsDayFree(DateTime date);
        Task<bool> FindUserRoomAsync(int userId, int modelId);
        Task Update(HotelInfo info, HotelAddress address);
    }
}
