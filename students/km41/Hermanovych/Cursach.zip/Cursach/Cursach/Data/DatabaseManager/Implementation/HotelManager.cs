﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cursach.Data.DatabaseManager.Interface;
using Cursach.Data.Model;
using Oracle.ManagedDataAccess.Client;

namespace Cursach.Data.DatabaseManager.Implementation
{
    public class HotelManager : IHotelManager
    {
        private readonly string _connectionString;

        public HotelManager(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<IEnumerable<Hotel>> GetAllAsync()
        {
            var result = new List<Hotel>();
            using (var connection = new OracleConnection())
            {
                connection.ConnectionString = _connectionString;
                await connection.OpenAsync();

                var command = connection.CreateCommand();
                var sql = "Select * from Hotel h\n" +
                            "left join HotelInfo hi on hi.id=h.HotelInfoId\n" + 
                            "left join HotelAddress ha on ha.id=h.HotelAddressId";
                command.CommandText = sql;
                var reader = await command.ExecuteReaderAsync();

                while (reader.ReadAsync().Result)
                {
                    var hotel = new Hotel
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        HotelInfoId = Convert.ToInt32(reader["HotelInfoId"]),
                        HotelAddressId = Convert.ToInt32(reader["HotelAddressId"])
                    };
                    var hotelInfo = new HotelInfo()
                    {
                        Description = reader["Description"].ToString(),
                        Title = reader["Title"].ToString(),
                        CountOfStars = Convert.ToInt32(reader["CountOfStars"])
                    };
                    var hotelAddress = new HotelAddress
                    {
                        Street = reader["Street"].ToString(),
                        City = reader["City"].ToString(),
                        Country = reader["Country"].ToString(),
                        HouseNumber = Convert.ToInt32(reader["HouseNumber"])
                    };
                    hotel.HotelInfo = hotelInfo;
                    hotel.HotelAddress = hotelAddress;
                    result.Add(hotel);
                }

                return result;
            }
        }

        public async Task<Hotel> AddAsync(HotelAddress address, HotelInfo info)
        {
            using (var connection = new OracleConnection())
            {
                connection.ConnectionString = _connectionString;
                await connection.OpenAsync();

                var hotelInfoId = await GetHotelInfoId(connection);
                var hotelAddressId = await GetHotelAddressId(connection);
                var hotelId = await GetHotelId(connection);

                var sql = "begin\n" +
                          "insert into hotelinfo(id,title,description,countOfStars)" +
                          $"values({hotelInfoId}," +
                          $"'{info.Title}'," +
                          $"'{info.Description}'," +
                          $"{info.CountOfStars});" +
                          $"insert into hoteladdress(id,street,city,country,housenumber)" +
                          $"values({hotelAddressId}," +
                          $"'{address.Street}'," +
                          $"'{address.City}'," +
                          $"'{address.Country}'," +
                          $"{address.HouseNumber});" +
                          $"insert into hotel(id,hotelInfoId,hoteladdressid)" +
                          $"values({hotelId}," +
                          $"{hotelInfoId}," +
                          $"{hotelAddressId});\n" +
                          $"end;";
                var command = connection.CreateCommand();
                command.CommandText = sql;

                var transaction = connection.BeginTransaction();
                try
                {
                    command.Transaction = transaction;
                    command.ExecuteNonQuery();
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return null;
                }
            }     
            var hotel = new Hotel
            {
                HotelAddress = address,
                HotelInfo = info
            };
            return hotel;
        }

        public async Task<Room> AddRoomAsync(Room room)
        {
            using (var connection = new OracleConnection(_connectionString))
            {
                await connection.OpenAsync();

                var roomId = await GetRoomId(connection);
                var sql = "insert into room(id,floor,numberOfRoom,hotelid,roomtypeid)\n" +
                          $"values({roomId}," +
                          $"{room.Floor}," +
                          $"{room.NumberOfRoom}," +
                          $"{room.HotelId}," +
                          $"{room.RoomTypeId});";
                var command = connection.CreateCommand();
                command.CommandText = sql;
                command.ExecuteNonQuery();

                return room;
            }
        }

        public async Task<IEnumerable<Room>> GetAllRoomAsync(int hotelId)
        {
            using (var connection = new OracleConnection(_connectionString))
            {
               await connection.OpenAsync();

                var rooms = new List<Room>();
                var sql = $"Select * from Room where hotelId={hotelId}";
                var command = connection.CreateCommand();
                command.CommandText = sql;

                var reader = await command.ExecuteReaderAsync();
                while (reader.ReadAsync().Result)
                {
                   var room = new Room
                   {
                       Id = Convert.ToInt32(reader["Id"]),
                       Floor = Convert.ToInt32(reader["Floor"]),
                       NumberOfRoom = Convert.ToInt32(reader["NumberOfRoom"]),
                   };
                    rooms.Add(room);
                }

                return rooms;
            }
        }

        public async Task<Room> GetRoomAsync(int roomId)
        {
            using (var connnection = new OracleConnection(_connectionString))
            {
                await connnection.OpenAsync();

                var sql = "Select * from Room r\n" +
                          "left join Hotel h on h.id=r.hotelId\n" +
                          "left join HotelInfo hi on hi.id=h.hotelInfoId\n" +
                          $"where r.id={roomId}";
                var command = connnection.CreateCommand();
                command.CommandText = sql;

                var reader = await command.ExecuteReaderAsync();
                while (reader.ReadAsync().Result)
                {
                    var room = new Room
                    {
                        Id=Convert.ToInt32(reader["Id"]),
                        Floor = Convert.ToInt32(reader["Floor"]),
                        NumberOfRoom = Convert.ToInt32(reader["NumberOfRoom"]),
                        HotelId = Convert.ToInt32(reader["HotelId"])
                    };
                    var hotelInfo = new HotelInfo
                    {
                        Title = reader["Title"].ToString(),
                        Description = reader["Description"].ToString(),
                        CountOfStars = Convert.ToInt32(reader["CountOfStars"])
                    };
                    room.HotelInfo = hotelInfo;
                    return room;
                }
                return null;
            }
        }

        private async Task<int> GetRoomId(OracleConnection connection)
        {
            var sql = "select room_seq.nextval from dual";
            var command = connection.CreateCommand();
            command.CommandText = sql;

            var reader = await command.ExecuteReaderAsync();
            var id = 0;
            while (reader.ReadAsync().Result)
            {
                if (reader.HasRows)
                {
                    id = reader.GetInt32(0);
                }
            }
            return id;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            using (var connection = new OracleConnection())
            {
                connection.ConnectionString = _connectionString;
                await connection.OpenAsync();

                var command = connection.CreateCommand();
                var hotel = await GetAsync(id);
                var sql =$"Delete from hotel h where h.id={id}";
                command.CommandText = sql;
                var sqlAll = $"begin\nDelete From hotelinfo where id={hotel.HotelInfoId};" +
                             $"Delete from hotelAddress where id={hotel.HotelAddressId};\nend;";
                var deleteAlLCmd = connection.CreateCommand();
                deleteAlLCmd.CommandText = sqlAll;
                var transaction = connection.BeginTransaction();
                try
                {
                    command.Transaction = transaction;
                    deleteAlLCmd.Transaction = transaction;
                    await command.ExecuteNonQueryAsync();
                    await deleteAlLCmd.ExecuteNonQueryAsync();
                    transaction.Commit();
                    return true;
                }
                catch(Exception ex)
                {
                    transaction.Rollback();
                    return false;
                }
            }
        }

        public async Task<bool> AddUserToRoomAsync(int userId, int modelId, DateTime modelBookDate)
        {
            using (var connection = new OracleConnection(_connectionString))
            {
                await connection.OpenAsync();

                var date = modelBookDate.ToString("yyyy/MM/dd");
                var sql = "begin\nInsert into user_room(userId,roomId,dateOfBook)\n" +
                          $"values({userId}," +
                          $"{modelId}," +
                          $"to_date('{date}','yyyy/mm/dd'));\nend;";
                var command = connection.CreateCommand();
                command.CommandText = sql;
                await command.ExecuteNonQueryAsync();
                return true;
            }
        }

        public async Task<bool> IsDayFree(DateTime date)
        {
            using (var connection = new OracleConnection())
            {
                connection.ConnectionString = _connectionString;
                await connection.OpenAsync();

                var dateOfBook = date.ToString("yyyy/MM/dd");
                var command = connection.CreateCommand();
                var sql = "Select * from user_room\n" +
                          $"where dateofbook=to_date('{dateOfBook}','yyyy/MM/dd')";
                command.CommandText = sql;
                var reader = await command.ExecuteReaderAsync();

                while (reader.ReadAsync().Result)
                {
                    if (reader.HasRows) return false;
                }

                return true;
            }
        }

        public async Task<bool> FindUserRoomAsync(int userId, int modelId)
        {
            using (var connection = new OracleConnection())
            {
                connection.ConnectionString = _connectionString;
                await connection.OpenAsync();

                var command = connection.CreateCommand();
                var sql = "Select * from user_room\n" +
                          $"where userId={userId} and roomId={modelId}";
                command.CommandText = sql;
                var reader = await command.ExecuteReaderAsync();

                while (reader.ReadAsync().Result)
                {
                    if (reader.HasRows) return true;
                }

                return false;
            }
        }

        public async Task Update(HotelInfo info, HotelAddress address)
        {
            using (var connection = new OracleConnection(_connectionString))
            {
                await connection.OpenAsync();

                var sql = $"begin\nUpdate HotelInfo set " +
                          $"title='{info.Title}'," +
                          $"description='{info.Description}'," +
                          $"countOfStars={info.CountOfStars}\n" +
                          $"where id='{info.Id}';" +
                          $"Update HotelAddress set " +
                          $"city='{address.City}'," +
                          $"country='{address.Country}'," +
                          $"street='{address.Street}'," +
                          $"houseNumber={address.HouseNumber}\n" +
                          $"where id={address.Id};\nend;";
                var command = connection.CreateCommand();
                command.CommandText = sql;
                var transaction = connection.BeginTransaction();
                try
                {
                    command.Transaction = transaction;
                    await command.ExecuteNonQueryAsync();
                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                }

            }
        }

        public async Task<Hotel> GetAsync(int id)
        {
            using (var connection = new OracleConnection())
            {
                connection.ConnectionString = _connectionString;
                await connection.OpenAsync();

                var command = connection.CreateCommand();
                var sql = "Select * from Hotel h\n" +
                            "left join HotelInfo hi on hi.id=h.HotelInfoId\n" +
                            "left join HotelAddress ha on ha.id=h.HotelAddressId\n" +
                            $"where h.id={id}";
                command.CommandText = sql;                                     
                var reader = await command.ExecuteReaderAsync();

                while (reader.ReadAsync().Result)
                {
                    var hotel = new Hotel
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        HotelInfoId = Convert.ToInt32(reader["HotelInfoId"]),
                        HotelAddressId = Convert.ToInt32(reader["HotelAddressId"])
                    };
                    var hotelInfo = new HotelInfo()
                    {
                        Description = reader["Description"].ToString(),
                        Title = reader["Title"].ToString(),
                        CountOfStars = Convert.ToInt32(reader["CountOfStars"])
                    };
                    var hotelAddress = new HotelAddress
                    {
                        Street = reader["Street"].ToString(),
                        City = reader["City"].ToString(),
                        Country = reader["Country"].ToString(),
                        HouseNumber = Convert.ToInt32(reader["HouseNumber"])
                    };
                    hotel.HotelInfo = hotelInfo;
                    hotel.HotelAddress = hotelAddress;
                    return hotel;
                }

                return null;
            }
        }

        private async Task<int> GetHotelId(OracleConnection connection)
        {
            var sql = "select hotel_seq.nextval from dual";
            var command = connection.CreateCommand();
            command.CommandText = sql;

            var reader = await command.ExecuteReaderAsync();
            var id = 0;
            while (reader.ReadAsync().Result)
            {
                if (reader.HasRows)
                {
                    id = reader.GetInt32(0);
                }
            }
            return id;
        }

        private async Task<int> GetHotelInfoId(OracleConnection connection)
        {
            var sql = "select hotelinfo_seq.nextval from dual";
            var command = connection.CreateCommand();
            command.CommandText = sql;

            var reader = await command.ExecuteReaderAsync();
            var id = 0;
            while (reader.ReadAsync().Result)
            {
                if (reader.HasRows)
                {
                    id = reader.GetInt32(0);
                }
            }
            return id;
        }
        private async Task<int> GetHotelAddressId(OracleConnection connection)
        {
            var sql = "select hoteladdress_seq.nextval from dual";
            var command = connection.CreateCommand();
            command.CommandText = sql;

            var reader = await command.ExecuteReaderAsync();
            var id = 0;
            while (reader.ReadAsync().Result)
            {
                if (reader.HasRows)
                {
                    id = reader.GetInt32(0);
                }
            }
            return id;
        }
    }
}
