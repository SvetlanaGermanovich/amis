﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Cursach.Service.Interfaces;
using Cursach.ViewModel;

namespace Cursach.Controllers
{
    public class HomeController : Controller
    {
        private readonly IHotelService _hotelService;

        public HomeController(IHotelService hotelService)
        {
            _hotelService = hotelService;
        }

        public async Task<ActionResult> Index()
        {
            var result = await _hotelService.GetAllHotelsAsync();
            return View(result);
        }

        public async Task<ActionResult> Booked(int id)
        {
            var rooms = await _hotelService.GetAllRoomAsync(id);
            return View(rooms);
        }

        public async Task<ActionResult> SelectedRoom(int id,DateTime?bookDate = null,string message = null)
        {
            var room = await _hotelService.GetRoomAsync(id);
            ViewBag.Message = "";
            if (bookDate != null)
            {
                ViewBag.Message = message;
                room.BookDate = bookDate.Value;
            }
            return View(room);
        }

        [HttpPost]
        public async Task<ActionResult> SelectedRoom(RoomViewModel room)
        {
            if (Request.Cookies["Auth cookie"] != null)
            {
                var userId = Int32.Parse(Request.Cookies["Auth cookie"].Values["userId"]);
                var result = await _hotelService.BookedRoomAsync(room, userId);
                if(result.Result)
                    return RedirectToAction("Booked", "Home", new {id = room.HotelId});
                return await SelectedRoom(room.Id,room.BookDate,result.Message);
            }
            return RedirectToAction("Index", "Account");
        } 
    }
}