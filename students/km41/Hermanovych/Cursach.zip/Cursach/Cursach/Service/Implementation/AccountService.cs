﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Cursach.Data.DatabaseManager.Interface;
using Cursach.Data.Model;
using Cursach.Service.Interfaces;
using Cursach.ViewModel;

namespace Cursach.Service.Implementation
{
    public class AccountService : IAccountService
    {

        private readonly IUserManager _userManager;

        public AccountService(IUserManager userManager)
        {
            _userManager = userManager;
        }

        public async Task<IEnumerable<AppUser>> GetAllUsersAsync()
        {
            return await _userManager.GetAllAsync();
        }


        public async Task<AppUser> SignInAsync(string email, string password)
        {
            return await _userManager.GetAsync(email,GetHash(password));
        }

        public async Task<AppUser> SignUpAsync(SignUpViewModel model)
        {

            var user = new AppUser
            {
                Email = model.Email,
                Password = GetHash(model.Password),
                UserRoleId = model.RoleId,
            };
            var userInfo = new UserInfo
            {
                Country = model.Country,
                DateOfBirth = model.DateOfBirth,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Gender = model.GenderEnum
            };
            var result = await _userManager.AddUserAsync(userInfo, user);
            return result;
        }

        public async Task<bool> DeleteUserAsync(int id)
        {
            return await _userManager.DeleteUserAsync(id);
        }

        private string GetHash(string text)
        {
            using (var sha256 = SHA256.Create())
            {
                var shaBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(text));
                return BitConverter.ToString(shaBytes).Replace("-", "").ToLower().Substring(0,40);
            }
        }

        private bool IsEqualHash(string serverHash, string clientHashValue)
        {
            return serverHash == clientHashValue;
        }
    }
}
