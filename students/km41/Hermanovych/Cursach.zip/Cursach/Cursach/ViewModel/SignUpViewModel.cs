﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cursach.Data.Model;

namespace Cursach.ViewModel
{
    public class SignUpViewModel
    {
        [Required]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        public GenderEnum GenderEnum { get; set; } = GenderEnum.None;

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime DateOfBirth { get; set; }  = DateTime.Today;
        public string Country { get; set; } = "Ukraine";
        public int RoleId { get; set; } = 1;
    }
}
