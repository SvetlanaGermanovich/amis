﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cursach.Data.Model;
using Cursach.ViewModel;

namespace Cursach.Data.DatabaseManager.Interface
{
    public interface IUserManager
    {
        Task<IEnumerable<AppUser>> GetAllAsync();
        Task<AppUser> GetAsync(string email, string password);
        Task<AppUser> AddUserAsync(UserInfo userInfo, AppUser user);
        Task<bool> DeleteUserAsync(int id);
    }
}
