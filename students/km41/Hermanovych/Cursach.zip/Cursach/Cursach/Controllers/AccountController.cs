﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Cursach.Service.Interfaces;
using Cursach.ViewModel;

namespace Cursach.Controllers
{
    public class AccountController: Controller
    {
        private readonly IAccountService _accountService;

        public AccountController(IAccountService accountService)
        {
            _accountService = accountService;
        }

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> Login(SignInViewModel model)
        {
            var result = await _accountService.SignInAsync(model.Email, model.Password);
            if (Request.Cookies["Auth cooki"] != null) return RedirectToAction("Index", "Home");

            var cookie = new HttpCookie("Auth cookie")
            {
                ["email"] = result.Email,
                ["userId"] = result.Id.ToString()
            };
            Response.Cookies.Add(cookie);
            return RedirectToAction("Index","Home");
        }

        public ActionResult Register()
        {
            return View(new SignUpViewModel());
        }

        [HttpPost]
        public async Task<ActionResult> Register(SignUpViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await _accountService.SignUpAsync(model);
                var cookie = new HttpCookie("Auth cookie")
                {
                    ["email"] = result.Email,
                    ["userId"] = result.Id.ToString()
                };
                Response.Cookies.Add(cookie);
                return RedirectToAction("Index", "Home");
            }
            return View(model);
        }
    }
}
