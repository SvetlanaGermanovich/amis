﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cursach.Data.DatabaseManager.Interface;
using Cursach.Data.Model;
using Cursach.Service.Interfaces;
using Cursach.ViewModel;

namespace Cursach.Service.Implementation
{
    public class HotelService   : IHotelService
    {

        private readonly IHotelManager _hotelManager;

        public HotelService(IHotelManager hotelManager)
        {
            _hotelManager = hotelManager;
        }

        public async Task<IEnumerable<Hotel>> GetAllHotelsAsync()
        {
            return await _hotelManager.GetAllAsync();
        }

        public async Task<Hotel> GetHotelAsyncById(int id)
        {
            return await _hotelManager.GetAsync(id);
        }

        public async Task<Hotel> AddHotelAsync(HotelViewModel model)
        {
            var hotelInfo = new HotelInfo
            {
                CountOfStars = model.CountOfStars,
                Description = model.Desctiption,
                Title = model.Title
            };
            var address = new HotelAddress
            {
                Country = model.Country,
                City = model.City,
                HouseNumber = model.HouseNumber,
                Street = model.Street
            };
            return await _hotelManager.AddAsync(address, hotelInfo);
        }

        public async Task<Room> AddRoomAsync(RoomViewModel model)
        {
            var room = new Room
            {
                Floor = model.Floor,
                HotelId = model.HotelId,
                NumberOfRoom = model.NumberOfRoom,
                RoomTypeId = model.RoomTypeId
            };
            return await _hotelManager.AddRoomAsync(room);
        }

        public async Task<IEnumerable<Room>> GetAllRoomAsync(int id)
        {
            return await _hotelManager.GetAllRoomAsync(id);
        }

        public async Task<bool> DeleteHotelAsync(int id)
        {
            return await _hotelManager.DeleteAsync(id);
        }

        public async Task<Response> BookedRoomAsync(RoomViewModel model, int userId)
        {
            var isFree = await _hotelManager.IsDayFree(model.BookDate);
            if (isFree)
            {
                var isBookedTheSameRoom = await _hotelManager.FindUserRoomAsync(userId, model.Id);
                if(isBookedTheSameRoom)
                    return new Response{Result = false, Message = "You have already book this room"};
                await _hotelManager.AddUserToRoomAsync(userId, model.Id, model.BookDate);
                return new Response{Result = true};
            }
            return new Response{Message = "This day isn't free", Result = false};
        }

        public async Task<RoomViewModel> GetRoomAsync(int id)
        {
            var room = await _hotelManager.GetRoomAsync(id);
            var model = new RoomViewModel
            {
              Id = room.Id,
              HotelId = room.HotelId,
              HotelInfo  = room.HotelInfo,
              Floor = room.Floor,
              NumberOfRoom = room.NumberOfRoom
            };
            return model;
        }

        public async Task UpdateHotelAsync(HotelViewModel model)
        {
            var info = new HotelInfo
            {
                Title = model.Title,
                Description = model.Desctiption,
                Id = model.HotelInfoId,
                CountOfStars = model.CountOfStars
            };
            var address=new HotelAddress
            {
                Id = model.HotelAddressId,
                Country = model.Country,
                City = model.City,
                Street = model.Street,
                HouseNumber = model.HouseNumber
            };
            await _hotelManager.Update(info, address);
        }
    }
}
