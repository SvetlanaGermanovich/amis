﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Results;
using System.Web.Mvc;
using Cursach.Service.Interfaces;
using Cursach.ViewModel;

namespace Cursach.Controllers
{
    public class AdminController: Controller
    {
        private readonly IHotelService _hotelService;

        public AdminController(IHotelService hotelService)
        {
            _hotelService = hotelService;
        }

        public async Task<ActionResult> Index()
        {
            var hotels = await _hotelService.GetAllHotelsAsync();
            return View(hotels);
        }

        public async Task<ActionResult> Managed(int id)
        {
            var hotel = await _hotelService.GetHotelAsyncById(id);
            var model = new HotelViewModel
            {
                Title = hotel.HotelInfo.Title,
                Id = hotel.Id,
                Country = hotel.HotelAddress.Country,
                CountOfStars = hotel.HotelInfo.CountOfStars,
                Desctiption = hotel.HotelInfo.Description,
                City = hotel.HotelAddress.City,
                Street = hotel.HotelAddress.Street,
                HouseNumber = hotel.HotelAddress.HouseNumber,
                HotelAddressId = hotel.HotelAddressId,
                HotelInfoId = hotel.HotelInfoId
            };
            return View(model);
        }

        public async Task<ActionResult> Delete(int id)
        {
            var hotel = await _hotelService.GetHotelAsyncById(id);
            var model = new HotelViewModel
            {
                Title = hotel.HotelInfo.Title,
                Id = hotel.Id,
                Country = hotel.HotelAddress.Country,
                CountOfStars = hotel.HotelInfo.CountOfStars,
                Desctiption = hotel.HotelInfo.Description,
                City = hotel.HotelAddress.City,
                Street = hotel.HotelAddress.Street,
                HouseNumber = hotel.HotelAddress.HouseNumber,
                HotelAddressId = hotel.HotelAddressId,
                HotelInfoId = hotel.HotelInfoId
            };
            return View(model);
        }



        [HttpPost]
        public async Task<ActionResult> Delete(HotelViewModel model)
        {
            var result = await _hotelService.DeleteHotelAsync(model.Id);
            if (result)
                return RedirectToAction("Index","Admin");
            return View(model);
        }

        [HttpPost]
        public async Task<ActionResult> Managed(HotelViewModel model)
        {
            if (ModelState.IsValid)
            {
                await _hotelService.UpdateHotelAsync(model);
                return RedirectToAction("Index");
            }
            return View(model);
        }

        public ActionResult AddHotel()
        {
            return View(new HotelViewModel());
        }

        [HttpPost]
        public async Task<ActionResult> AddHotel(HotelViewModel model)
        {
            if (ModelState.IsValid)
            {
                await _hotelService.AddHotelAsync(model);
                return RedirectToAction("Index");
            }
            return View(model);
        }
    }
}
