﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cursach.Data.DatabaseManager.Implementation;
using Cursach.Data.DatabaseManager.Interface;
using Cursach.Service.Implementation;
using Cursach.Service.Interfaces;
using Ninject.Modules;

namespace Cursach.Util
{
    public class NinjectRegistration : NinjectModule
    {
        public override void Load()
        {
            Bind<IHotelManager>().To<HotelManager>()
                .WithConstructorArgument("connectionString",Constants.ConnectionString);
            Bind<IUserManager>().To<UserManager>()
                .WithConstructorArgument("connectionString", Constants.ConnectionString);
            Bind<IHotelService>().To<HotelService>();
            Bind<IAccountService>().To<AccountService>();
        }
    }
}
