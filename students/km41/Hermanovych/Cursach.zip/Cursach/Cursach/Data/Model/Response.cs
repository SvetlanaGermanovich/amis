﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cursach.Data.Model
{
    public class Response
    {
        public bool Result { get; set; }
        public string Message { get; set; }
    }
}
