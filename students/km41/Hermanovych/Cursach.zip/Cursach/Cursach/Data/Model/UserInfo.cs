﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cursach.Data.Model
{
    public class UserInfo
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public GenderEnum Gender { get; set; } = GenderEnum.None;
        public string Country { get; set; }
    }

    public enum GenderEnum
    {
      None = 0,
      Male = 1,
      Female = 2
    }
}
