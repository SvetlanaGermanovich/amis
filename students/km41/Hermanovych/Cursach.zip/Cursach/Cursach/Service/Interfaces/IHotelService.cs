﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cursach.Data.Model;
using Cursach.ViewModel;

namespace Cursach.Service.Interfaces
{
    public interface IHotelService
    {
        Task<IEnumerable<Hotel>> GetAllHotelsAsync();
        Task<Hotel> GetHotelAsyncById(int id);
        Task<Hotel> AddHotelAsync(HotelViewModel model);
        Task<Room> AddRoomAsync(RoomViewModel model);
        Task<IEnumerable<Room>> GetAllRoomAsync(int id);
        Task<bool> DeleteHotelAsync(int id);
        Task<Response> BookedRoomAsync(RoomViewModel model,int userId);
        Task<RoomViewModel> GetRoomAsync(int id);
        Task UpdateHotelAsync(HotelViewModel model);
    }
}
