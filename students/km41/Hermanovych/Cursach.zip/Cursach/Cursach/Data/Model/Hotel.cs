﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cursach.Data.Model
{
    public class Hotel
    {
        public int Id { get; set; }
        public int HotelInfoId { get; set; }
        public int HotelAddressId { get; set; }
        public HotelInfo HotelInfo { get; set; }
        public HotelAddress HotelAddress { get; set; }
    }
}
