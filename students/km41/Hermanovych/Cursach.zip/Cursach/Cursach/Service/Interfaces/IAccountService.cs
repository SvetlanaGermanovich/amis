﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cursach.Data.Model;
using Cursach.ViewModel;

namespace Cursach.Service.Interfaces
{
    public interface IAccountService
    {
        Task<IEnumerable<AppUser>> GetAllUsersAsync();
        Task<AppUser> SignInAsync(string email, string password);
        Task<AppUser> SignUpAsync(SignUpViewModel model);
    }
}
